const YOUR_PET = 'your-pet';
const SELL = 'sell';
const LOST_FOUND = 'lost-found';
const IN_GOOD_HANDS = 'for-free';

export { YOUR_PET, SELL, LOST_FOUND, IN_GOOD_HANDS };
