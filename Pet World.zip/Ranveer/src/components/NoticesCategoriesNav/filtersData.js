export const filters = [
  { filter: 'sell', path: 'sell' },
  { filter: 'lost', path: 'lost-found' },
  { filter: 'found', path: 'for-free' },
  { filter: 'favourite pets', path: 'favorite' },
  { filter: 'my pets', path: 'my-pets' },
];
