import AddPetForm from 'components/AddPetForm/AddPetForm';
import React from 'react';

const AddPet = () => {
  return (
    <>
      <AddPetForm />
    </>
  );
};

export default AddPet;
