import PetsList from 'components/PetsList/PetsList';
import React from 'react';

const PetsData = () => {
  return (
    <>
      <PetsList />
    </>
  );
};

export default PetsData;
