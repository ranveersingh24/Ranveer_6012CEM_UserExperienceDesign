export const selectIsLoggedIn = state => state.auth.isLoggedIn;

export const selectIsFirstEnter = state => state.auth.isFirstEnter;

export const selectUser = state => state.auth.user;

export const selectIsRefreshing = state => state.auth.isRefreshing;

export const selectError = state => state.auth.error;

export const selectIsLoading = state => state.auth.isLoading;
