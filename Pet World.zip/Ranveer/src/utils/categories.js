export const categories = {
  SELL: 'sell',
  LOST_FOUND: 'lost-found',
  IN_GOOD_HANDS: 'in-good-hands',
  FAVORITE_ADS: 'favorite-ads',
  MY_ADS: 'my-ads',
};
