import { ReactComponent as Pawprint } from 'assets/images/icons/pawprint.svg';
export { Pawprint };
