export const selectIsLoadingNews = state => state.news.isLoadingNews;

export const selectAllNews = state => state.news.news;

export const selectSearchNews = state => state.news.searchNews;

export const selectTotalNews = state => state.news.totalNews;
